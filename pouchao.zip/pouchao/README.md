# পৌঁছাও – পার্সেল ট্র্যাকিং অ্যাপ

প্রাপকের জন্য পার্সেল ট্র্যাকিং অ্যাপ। Next.js 14 (App Router) + Supabase (Postgres)।
চারটি ট্যাব: হোম, পার্সেল, নোটিফিকেশন, প্রোফাইল। মোবাইল-ফার্স্ট, ডার্ক মোড সাপোর্টসহ।

## চালু করার ধাপ
1. supabase.com-এ প্রজেক্ট খুলুন, SQL Editor-এ `supabase/schema.sql` চালান।
2. `.env.example` কপি করে `.env.local` বানান, মান বসান।
3. `npm install && npm run dev` → http://localhost:3000
4. `BD1001` লিখে খুঁজুন।

## স্ট্যাটাস আপডেট (কুরিয়ার টিম / সার্ভার থেকে)
```
curl -X POST http://localhost:3000/api/parcels/BD1001/status \
  -H "x-admin-key: $ADMIN_KEY" -H "content-type: application/json" \
  -d '{"status":3,"progress":80,"note":"আপনার এলাকায় পৌঁছেছে"}'
```
status: ০ অর্ডার, ১ পিকআপ, ২ হাব, ৩ ডেলিভারির পথে, ৪ সম্পন্ন। progress: ০–১০০।

## GitHub-এ আপলোড
```
git init
git add .
git commit -m "প্রথম কমিট: পৌঁছাও অ্যাপ"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/pouchao.git
git push -u origin main
```
`.env.local` কখনো আপলোড হবে না (`.gitignore`-এ আছে)। key গোপন রাখুন।

## Vercel-এ লাইভ করা
GitHub রিপো Vercel-এ import করুন, তিনটি env variable (`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_KEY`) বসিয়ে Deploy দিন।

## পরের ধাপ
- আসল GPS ম্যাপ (Leaflet; lat/lng আগে থেকেই ডাটাবেসে আছে)
- SMS নোটিফিকেশন, অ্যাডমিন প্যানেল, কুরিয়ার API ইন্টিগ্রেশন
- `/api/track`-এ rate limiting
