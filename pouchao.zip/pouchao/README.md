# পৌঁছাও – পার্সেল ট্র্যাকিং

Next.js 14 (App Router) + Supabase (Postgres)।

## চালু করার ধাপ
1. supabase.com-এ একটি প্রজেক্ট খুলুন, SQL Editor-এ `supabase/schema.sql` চালান।
2. `.env.example` কপি করে `.env.local` বানান, মান বসান।
3. `npm install && npm run dev` → http://localhost:3000
4. `BD1001` লিখে ট্র্যাক করুন।

## স্ট্যাটাস আপডেট (কুরিয়ার টিম / সার্ভার থেকে)
curl -X POST http://localhost:3000/api/parcels/BD1001/status \
  -H "x-admin-key: $ADMIN_KEY" -H "content-type: application/json" \
  -d '{"status":4,"note":"ডেলিভারি সম্পন্ন"}'

## ডিপ্লয়
Vercel-এ পুশ করুন, তিনটি env variable বসান।

## পরের ধাপ
- লাইভ ম্যাপ (Leaflet; lat/lng আগে থেকেই ডাটাবেসে আছে)
- SMS নোটিফিকেশন (status API থেকে ট্রিগার)
- অ্যাডমিন প্যানেল, কুরিয়ার API ইন্টিগ্রেশন
- /api/track-এ rate limiting (আইডি আন্দাজ করে খোঁজা ঠেকাতে)
