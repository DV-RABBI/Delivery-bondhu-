create table parcels (
  id uuid primary key default gen_random_uuid(),
  tracking_id text unique not null,
  item text not null,
  sender text,
  recipient_name text,
  recipient_phone text,
  address text,
  status smallint not null default 0,  -- 0..4, see lib/steps.js
  eta text,
  rider_name text,
  rider_phone text,
  lat double precision,
  lng double precision,
  progress smallint default 0,         -- 0..100 route progress
  created_at timestamptz default now()
);

create table parcel_events (
  id bigserial primary key,
  parcel_id uuid not null references parcels(id) on delete cascade,
  status smallint not null,
  note text,
  created_at timestamptz default now()
);

-- Server-only access: RLS on, no public policies.
alter table parcels enable row level security;
alter table parcel_events enable row level security;

insert into parcels (tracking_id, item, sender, address, status, eta, rider_name, rider_phone, progress)
values ('BD1001', 'ওয়্যারলেস হেডফোন', 'টেকশপ বিডি', 'মিরপুর ১০, ঢাকা', 3, 'আজ বিকাল ৫টার মধ্যে', 'রফিক', '01700000000', 62);

insert into parcel_events (parcel_id, status)
select id, s from parcels, generate_series(0, 3) s where tracking_id = 'BD1001';
