import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { normalizeId } from '@/lib/steps';

// POST /api/parcels/BD1001/status   header: x-admin-key
// body: { "status": 3, "note": "...", "lat": 23.8, "lng": 90.4 }
export async function POST(req, { params }) {
  if (req.headers.get('x-admin-key') !== process.env.ADMIN_KEY) {
    return NextResponse.json({ error: 'অনুমতি নেই' }, { status: 401 });
  }
  const { status, note, lat, lng } = await req.json();
  if (!Number.isInteger(status) || status < 0 || status > 4) {
    return NextResponse.json({ error: 'status হবে ০ থেকে ৪' }, { status: 400 });
  }

  const { data: p, error } = await db
    .from('parcels')
    .update({ status, lat, lng })
    .eq('tracking_id', normalizeId(params.id))
    .select('id')
    .maybeSingle();

  if (error || !p) return NextResponse.json({ error: 'পার্সেল পাওয়া যায়নি' }, { status: 404 });

  await db.from('parcel_events').insert({ parcel_id: p.id, status, note });
  return NextResponse.json({ ok: true });
}
