import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { normalizeId } from '@/lib/steps';

export async function GET(req) {
  const id = normalizeId(new URL(req.url).searchParams.get('id') || '');
  if (!id) return NextResponse.json({ error: 'আইডি দিন' }, { status: 400 });

  const { data: p } = await db
    .from('parcels')
    .select('id, tracking_id, item, sender, address, status, eta, rider_name, rider_phone, lat, lng, progress')
    .eq('tracking_id', id)
    .maybeSingle();

  if (!p) return NextResponse.json({ error: 'পার্সেল পাওয়া যায়নি' }, { status: 404 });

  const { data: events } = await db
    .from('parcel_events')
    .select('status, note, created_at')
    .eq('parcel_id', p.id)
    .order('created_at');

  const { id: _internal, ...parcel } = p;
  return NextResponse.json({ parcel, events: events || [] });
}
