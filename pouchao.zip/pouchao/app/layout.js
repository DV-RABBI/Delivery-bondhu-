import { Hind_Siliguri } from 'next/font/google';
import './globals.css';

const font = Hind_Siliguri({ subsets: ['bengali', 'latin'], weight: ['400', '500', '600', '700'] });

export const metadata = { title: 'পৌঁছাও – পার্সেল ট্র্যাকিং' };
export const viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' };

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body className={font.className}>{children}</body>
    </html>
  );
}
