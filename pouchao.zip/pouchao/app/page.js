'use client';
import { useState } from 'react';
import { STEPS } from '@/lib/steps';

const fmt = (d) =>
  new Date(d).toLocaleString('bn-BD', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });

export default function Home() {
  const [q, setQ] = useState('');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);

  async function track(e) {
    e.preventDefault();
    setLoading(true); setErr(''); setRes(null);
    try {
      const r = await fetch('/api/track?id=' + encodeURIComponent(q));
      const j = await r.json();
      r.ok ? setRes(j) : setErr(j.error);
    } catch {
      setErr('নেটওয়ার্কে সমস্যা। আবার চেষ্টা করুন।');
    }
    setLoading(false);
  }

  const p = res?.parcel;
  const done = p?.status === 4;
  const timeOf = (i) => res.events.find((ev) => ev.status === i)?.created_at;

  return (
    <main>
      <h1>আপনার পার্সেল এখন কোথায়?</h1>
      <form className="search" onSubmit={track}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ট্র্যাকিং আইডি" aria-label="ট্র্যাকিং আইডি" />
        <button disabled={loading || !q.trim()}>{loading ? 'খুঁজছি…' : 'ট্র্যাক করুন'}</button>
      </form>

      {err && <div className="err"><b>{err}</b></div>}

      {p && (
        <div className="card">
          <div className={'status' + (done ? ' done' : '')}>
            <b>{STEPS[p.status]}</b>
            <span>{p.eta}</span>
          </div>
          <div className="sec">
            <h2>অবস্থা</h2>
            <ol>
              {STEPS.map((s, i) => (
                <li key={s} className={i <= p.status ? (i === p.status && !done ? 'on now' : 'on') : 'off'}>
                  <span className="dot" />
                  {s}
                  <small>{timeOf(i) ? fmt(timeOf(i)) : 'এখনো হয়নি'}</small>
                </li>
              ))}
            </ol>
          </div>
          <div className="sec">
            <h2>পার্সেলের তথ্য</h2>
            <dl>
              <dt>পণ্য</dt><dd>{p.item}</dd>
              <dt>প্রেরক</dt><dd>{p.sender}</dd>
              <dt>ঠিকানা</dt><dd>{p.address}</dd>
              <dt>আইডি</dt><dd>{p.tracking_id}</dd>
            </dl>
          </div>
          {!done && p.rider_name && (
            <div className="sec rider">
              <div><small>ডেলিভারি ম্যান</small><b>{p.rider_name}</b></div>
              <a className="call" href={'tel:' + p.rider_phone}>কল করুন</a>
            </div>
          )}
        </div>
      )}
    </main>
  );
}
