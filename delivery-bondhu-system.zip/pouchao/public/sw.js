self.addEventListener('push', (e) => {
  const d = e.data ? e.data.json() : { title: 'নতুন অর্ডার' };
  e.waitUntil(self.registration.showNotification(d.title, { body: d.body, icon: '/icon-192.png', vibrate: [300, 100, 300], tag: d.tracking_id }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(clients.openWindow('/rider'));
});
