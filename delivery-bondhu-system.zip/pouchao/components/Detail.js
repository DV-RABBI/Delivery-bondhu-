import { STEPS } from '@/lib/steps';
import RouteMap from './RouteMap';

const fmt = (d) =>
  new Date(d).toLocaleString('bn-BD', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export default function Detail({ data, onBack }) {
  const { parcel: p, events } = data;
  const done = p.status === 4;
  const timeOf = (i) => events.find((e) => e.status === i)?.created_at;

  return (
    <>
      <header>
        <button className="back" onClick={onBack}>← পেছনে</button>
        <small>{p.tracking_id}</small>
        <b>{p.item}</b>
      </header>
      <div className="wrap">
        <div className="card">
          <div className={'status' + (done ? ' done' : '')}><b>{STEPS[p.status]}</b>{p.eta}</div>
          {p.status === 3 && <RouteMap progress={p.progress || 0} />}
          <div className="sec">
            <ol>
              {STEPS.map((s, i) => (
                <li key={s} className={i <= p.status ? (i === p.status && !done ? 'on now' : 'on') : 'off'}>
                  <span className="dot" />{s}
                  <small>{timeOf(i) ? fmt(timeOf(i)) : 'এখনো হয়নি'}</small>
                </li>
              ))}
            </ol>
          </div>
          <div className="sec">
            <span className="muted">প্রেরক</span>{p.sender}<br />
            <span className="muted">ঠিকানা</span>{p.address}
          </div>
          {!done && p.rider?.name && (
            <div className="sec row">
              <div><span className="muted">ডেলিভারি ম্যান</span><b>{p.rider?.name}</b></div>
              <a className="call" href={'tel:' + p.rider?.phone}>কল করুন</a>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
