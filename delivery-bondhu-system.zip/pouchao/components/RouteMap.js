'use client';
import { useEffect, useRef } from 'react';

const D = 'M30 140 C80 130 90 60 150 70 S240 120 290 35';

// Stylised route. Swap for Leaflet when you want real GPS (lat/lng are in the DB).
export default function RouteMap({ progress = 0 }) {
  const path = useRef(), done = useRef(), rider = useRef();
  useEffect(() => {
    const L = path.current.getTotalLength();
    const pt = path.current.getPointAtLength((L * progress) / 100);
    done.current.style.strokeDasharray = `${(L * progress) / 100} ${L}`;
    rider.current.setAttribute('transform', `translate(${pt.x} ${pt.y})`);
  }, [progress]);

  return (
    <div className="map">
      <svg viewBox="0 0 320 170" role="img" aria-label="ডেলিভারির রুট">
        <path ref={path} d={D} fill="none" stroke="var(--line)" strokeWidth="5" strokeLinecap="round" strokeDasharray="2 9" />
        <path ref={done} d={D} fill="none" stroke="var(--go)" strokeWidth="5" strokeLinecap="round" />
        <circle cx="30" cy="140" r="8" fill="var(--ink)" />
        <path d="M290 18c-9 0-15 7-15 15 0 11 15 24 15 24s15-13 15-24c0-8-6-15-15-15z" fill="var(--tape)" stroke="var(--ink)" strokeWidth="2" />
        <circle cx="290" cy="33" r="5" fill="var(--ink)" />
        <g ref={rider}>
          <circle className="pulse" r="9" fill="var(--tape)" />
          <circle r="9" fill="var(--tape)" stroke="var(--ink)" strokeWidth="3" />
        </g>
      </svg>
    </div>
  );
}
