create extension if not exists pgcrypto;

create table shops (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, address text,
  api_key_hash text unique not null,           -- sha256 of the shop's secret key
  active boolean default true, created_at timestamptz default now()
);

create table riders (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text unique not null,
  token_hash text unique not null,             -- sha256 of the rider's login token
  online boolean default false,
  lat double precision, lng double precision,
  created_at timestamptz default now()
);

-- status: 0 অর্ডার নেওয়া (অপেক্ষমাণ) 1 ডেলিভারি ম্যান নির্ধারিত 2 পিকআপ 3 পথে 4 সম্পন্ন
create table parcels (
  id uuid primary key default gen_random_uuid(),
  tracking_id text unique not null,
  shop_id uuid references shops(id), rider_id uuid references riders(id),
  item text not null, sender text,
  pickup_address text, address text not null,
  customer_name text, customer_phone text,
  cod_amount integer default 0,
  delivery_otp text,                           -- customer tells this to the rider at the door
  external_ref text,                           -- the shop's own order number
  status smallint not null default 0, eta text,
  lat double precision, lng double precision, progress smallint default 0,
  created_at timestamptz default now(), accepted_at timestamptz
);
create unique index on parcels (shop_id, external_ref) where external_ref is not null;
create index on parcels (status, rider_id);

create table parcel_events (
  id bigserial primary key,
  parcel_id uuid not null references parcels(id) on delete cascade,
  status smallint not null, note text, created_at timestamptz default now()
);

create table push_subs (
  id bigserial primary key,
  rider_id uuid not null references riders(id) on delete cascade,
  endpoint text unique not null, sub jsonb not null
);

-- Server-only access (service role). No public policies.
alter table shops enable row level security;
alter table riders enable row level security;
alter table parcels enable row level security;
alter table parcel_events enable row level security;
alter table push_subs enable row level security;

-- Atomic accept: only ONE rider can win a job.
create or replace function accept_parcel(p_tracking text, p_rider uuid) returns boolean
language plpgsql as $$
declare n int;
begin
  update parcels set rider_id = p_rider, status = 1, accepted_at = now()
   where tracking_id = p_tracking and status = 0 and rider_id is null;
  get diagnostics n = row_count;
  if n = 1 then
    insert into parcel_events (parcel_id, status, note)
    select id, 1, 'ডেলিভারি ম্যান নিশ্চিত করেছেন' from parcels where tracking_id = p_tracking;
  end if;
  return n = 1;
end $$;

-- DEV ONLY: demo shop & rider. Change/remove before going live!
insert into shops (name, phone, address, api_key_hash)
values ('ডেমো শপ', '01700000001', 'বসুন্ধরা, ঢাকা', encode(digest('demo-shop-key','sha256'),'hex'));
insert into riders (name, phone, token_hash)
values ('রফিক', '01700000002', encode(digest('demo-rider-token','sha256'),'hex'));
