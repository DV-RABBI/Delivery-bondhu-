'use client';
import { useCallback, useEffect, useState } from 'react';

const b64 = (s) => {
  const r = atob((s + '='.repeat((4 - (s.length % 4)) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...r].map((c) => c.charCodeAt(0)));
};
const NEXT = { 1: 'পিকআপ করেছি', 2: 'রওনা দিয়েছি', 3: 'ডেলিভারি সম্পন্ন' };

export default function Rider() {
  const [token, setToken] = useState('');
  const [input, setInput] = useState('');
  const [online, setOnline] = useState(false);
  const [jobs, setJobs] = useState({ available: [], mine: [] });
  const [msg, setMsg] = useState('');

  useEffect(() => { setToken(localStorage.getItem('rider:token') || ''); }, []);

  const call = useCallback(async (url, body) => {
    const r = await fetch(url, {
      method: body ? 'POST' : 'GET',
      headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
      body: body ? JSON.stringify(body) : undefined,
    });
    return { ok: r.ok, j: await r.json().catch(() => ({})) };
  }, [token]);

  const load = useCallback(async () => {
    if (!token) return;
    const { ok, j } = await call('/api/rider/jobs');
    if (ok) setJobs(j); else setMsg(j.error || 'সমস্যা হয়েছে');
  }, [token, call]);

  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);

  async function toggle() {
    let subscription;
    if (!online && 'serviceWorker' in navigator && 'PushManager' in window && process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY) {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js');
        if ((await Notification.requestPermission()) === 'granted') {
          subscription = (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY) })).toJSON();
        }
      } catch {}
    }
    await call('/api/rider/online', { online: !online, subscription });
    setOnline(!online);
  }

  async function accept(id) {
    const { ok, j } = await call(`/api/rider/jobs/${id}/accept`, {});
    setMsg(ok ? '' : j.error); load();
  }
  async function step(p) {
    const next = p.status + 1;
    const otp = next === 4 ? window.prompt('কাস্টমারের কাছ থেকে ৪ ডিজিটের OTP নিন') : undefined;
    if (next === 4 && !otp) return;
    const { ok, j } = await call(`/api/rider/jobs/${p.tracking_id}/status`, { status: next, otp });
    setMsg(ok ? '' : j.error); load();
  }

  if (!token) return (
    <main><h1>ডেলিভারি ম্যান লগইন</h1>
      <form className="search" onSubmit={(e) => { e.preventDefault(); localStorage.setItem('rider:token', input.trim()); setToken(input.trim()); }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="আপনার টোকেন" aria-label="টোকেন" />
        <button className="go">ঢুকুন</button>
      </form></main>
  );

  return (
    <>
      <div id="app">
        <header>
          <small>{jobs.rider?.name}</small><b>ডেলিভারি ম্যান</b>
        </header>
        <div className="wrap">
          <div className="card"><div className="row"><span>{online ? 'অনলাইন — অর্ডার আসবে' : 'অফলাইন'}</span>
            <button className="sw" role="switch" aria-label="অনলাইন" aria-checked={online} onClick={toggle} /></div></div>
          {msg && <p className="muted">{msg}</p>}

          <h2>আমার চলমান অর্ডার</h2>
          {jobs.mine.length === 0 && <p className="muted">কোনো চলমান অর্ডার নেই।</p>}
          {jobs.mine.map((p) => (
            <div className="card" key={p.tracking_id}><div className="sec" style={{ borderTop: 0 }}>
              <b>{p.item}</b> <small>{p.tracking_id}</small>
              <p>পিকআপ: {p.pickup_address}<br />ডেলিভারি: {p.address}<br />কাস্টমার: {p.customer_name} <a href={'tel:' + p.customer_phone}>{p.customer_phone}</a>
                {p.cod_amount > 0 && <><br />ক্যাশ নিতে হবে: ৳{p.cod_amount}</>}</p>
              <button className="go" style={{ width: '100%', minHeight: 44 }} onClick={() => step(p)}>{NEXT[p.status]}</button>
            </div></div>
          ))}

          <h2>নতুন অর্ডার ({jobs.available.length})</h2>
          {jobs.available.map((p) => (
            <div className="card" key={p.tracking_id}><div className="sec" style={{ borderTop: 0 }}>
              <b>{p.item}</b>
              <p>{p.pickup_address} → {p.address}{p.cod_amount > 0 && <><br />ক্যাশ: ৳{p.cod_amount}</>}</p>
              <button className="go" style={{ width: '100%', minHeight: 44 }} onClick={() => accept(p.tracking_id)}>গ্রহণ করুন</button>
            </div></div>
          ))}
        </div>
      </div>
    </>
  );
}
