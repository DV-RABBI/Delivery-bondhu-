'use client';
import { useEffect, useState } from 'react';
import { STEPS } from '@/lib/steps';
import { useLocal } from '@/lib/useLocal';
import Detail from '@/components/Detail';

const ICONS = {
  home: <path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z" />,
  box: <><path d="M21 8l-9-5-9 5v8l9 5 9-5z" /><path d="M3 8l9 5 9-5M12 13v8" /></>,
  bell: <><path d="M6 16V11a6 6 0 0112 0v5l2 2H4z" /><path d="M10 21h4" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></>,
};
const TABS = [['home', 'হোম'], ['box', 'পার্সেল'], ['bell', 'নোটিফিকেশন'], ['user', 'প্রোফাইল']];

const Chip = ({ s }) => <span className={'chip ' + (s === 4 ? 'done' : s < 3 ? 'hub' : '')}>{STEPS[s]}</span>;

export default function App() {
  const [tab, setTab] = useState('home');
  const [open, setOpen] = useState(null);       // tracking id
  const [ids, setIds] = useLocal('pouchao:ids', []);
  const [profile, setProfile] = useLocal('pouchao:profile', { name: '', phone: '', sms: true, push: true });
  const [data, setData] = useState({});         // id -> { parcel, events }
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');

  async function fetchOne(id) {
    const r = await fetch('/api/track?id=' + encodeURIComponent(id));
    const j = await r.json();
    return r.ok ? j : null;
  }

  useEffect(() => {
    ids.forEach(async (id) => {
      const j = await fetchOne(id);
      if (j) setData((d) => ({ ...d, [id]: j }));
    });
  }, [ids]);

  async function find(e) {
    e.preventDefault();
    setErr('');
    const j = await fetchOne(q);
    if (!j) return setErr('পার্সেল পাওয়া যায়নি। আইডি আবার দেখুন।');
    const id = j.parcel.tracking_id;
    setData((d) => ({ ...d, [id]: j }));
    if (!ids.includes(id)) setIds([id, ...ids]);
    setQ(''); setOpen(id);
  }

  const list = ids.map((id) => data[id]).filter(Boolean);
  const active = list.filter((d) => d.parcel.status < 4);
  const notes = list
    .flatMap((d) => d.events.map((e) => ({ ...e, item: d.parcel.item })))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const go = (t) => { setTab(t); setOpen(null); setErr(''); };

  let view;
  if (open && data[open]) {
    view = <Detail data={data[open]} onBack={() => setOpen(null)} />;
  } else if (tab === 'home') {
    const hero = active[0]?.parcel;
    view = (
      <>
        <header><small>স্বাগতম</small><b>হ্যালো{profile.name ? ', ' + profile.name : ''}</b></header>
        <div className="wrap">
          <form className="search" onSubmit={find}>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ট্র্যাকিং আইডি লিখুন" aria-label="ট্র্যাকিং আইডি" />
            <button className="go" disabled={!q.trim()}>খুঁজুন</button>
          </form>
          {err && <p className="muted" style={{ margin: '-6px 0 12px' }}>{err}</p>}
          <div className="stats">
            <div><b>{active.length}</b><span className="muted">চলমান</span></div>
            <div><b>{list.length - active.length}</b><span className="muted">সম্পন্ন</span></div>
            <div><b>{list.length}</b><span className="muted">মোট</span></div>
          </div>
          <h2>এখন যেটা পথে</h2>
          {hero ? (
            <div className="card">
              <button className="hero" onClick={() => setOpen(hero.tracking_id)}>
                <div className="row" style={{ padding: 0 }}>
                  <div><b>{hero.item}</b><small>{hero.tracking_id} · {hero.eta}</small></div>
                  <Chip s={hero.status} />
                </div>
                <div className="bar"><i style={{ width: (hero.status + 1) * 20 + '%' }} /></div>
              </button>
            </div>
          ) : <p className="muted">কোনো চলমান পার্সেল নেই। উপরে আইডি দিয়ে খুঁজুন।</p>}
        </div>
      </>
    );
  } else if (tab === 'box') {
    view = (
      <>
        <header><small>সব পার্সেল</small><b>আমার পার্সেল</b></header>
        <div className="wrap">
          {list.length ? (
            <div className="card">
              {list.map(({ parcel: p }) => (
                <button key={p.tracking_id} className="row" onClick={() => setOpen(p.tracking_id)}>
                  <div><b>{p.item}</b><small>{p.tracking_id} · {p.sender}</small></div>
                  <Chip s={p.status} />
                </button>
              ))}
            </div>
          ) : <p className="muted">এখনো কোনো পার্সেল যোগ করেননি।</p>}
        </div>
      </>
    );
  } else if (tab === 'bell') {
    view = (
      <>
        <header><small>আপডেট</small><b>নোটিফিকেশন</b></header>
        <div className="wrap">
          {notes.length ? (
            <div className="card">
              {notes.map((n, i) => (
                <div key={i} className="row">
                  <div><b>{n.item}</b><small>{STEPS[n.status]}</small></div>
                  <small>{new Date(n.created_at).toLocaleString('bn-BD', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</small>
                </div>
              ))}
            </div>
          ) : <p className="muted">কোনো আপডেট নেই।</p>}
        </div>
      </>
    );
  } else {
    const Sw = ({ k, t }) => (
      <div className="row">
        <span>{t}</span>
        <button className="sw" role="switch" aria-label={t} aria-checked={profile[k]} onClick={() => setProfile({ ...profile, [k]: !profile[k] })} />
      </div>
    );
    view = (
      <>
        <header><small>অ্যাকাউন্ট</small><b>প্রোফাইল</b></header>
        <div className="wrap">
          <div className="card">
            <div className="row"><input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} placeholder="আপনার নাম" aria-label="নাম" /></div>
            <div className="row"><input value={profile.phone} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} placeholder="ফোন নম্বর" inputMode="tel" aria-label="ফোন" /></div>
          </div>
          <h2>নোটিফিকেশন</h2>
          <div className="card"><Sw k="sms" t="SMS আপডেট" /><Sw k="push" t="পুশ নোটিফিকেশন" /></div>
        </div>
      </>
    );
  }

  return (
    <>
      <div id="app">{view}</div>
      <nav>
        <div>
          {TABS.map(([k, t]) => (
            <button key={k} onClick={() => go(k)} aria-current={!open && tab === k}>
              <svg viewBox="0 0 24 24">{ICONS[k]}</svg>{t}
            </button>
          ))}
        </div>
      </nav>
    </>
  );
}
