import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { shopFrom } from '@/lib/auth';
import { notifyRiders } from '@/lib/push';

const rnd = (n) => String(Math.floor(Math.random() * 10 ** n)).padStart(n, '0');

// POST /api/v1/deliveries   header: x-api-key
// { item, pickup_address, address, customer_name, customer_phone, cod_amount, external_ref }
export async function POST(req) {
  const shop = await shopFrom(req);
  if (!shop) return NextResponse.json({ error: 'invalid api key' }, { status: 401 });

  const b = await req.json().catch(() => ({}));
  if (!b.item || !b.address || !b.customer_phone) {
    return NextResponse.json({ error: 'item, address, customer_phone required' }, { status: 400 });
  }

  // Idempotent: same external_ref returns the existing delivery.
  if (b.external_ref) {
    const { data: ex } = await db.from('parcels').select('tracking_id, status, delivery_otp').eq('shop_id', shop.id).eq('external_ref', b.external_ref).maybeSingle();
    if (ex) return NextResponse.json(ex);
  }

  const row = {
    shop_id: shop.id, sender: shop.name, item: b.item,
    pickup_address: b.pickup_address || shop.address, address: b.address,
    customer_name: b.customer_name, customer_phone: b.customer_phone,
    cod_amount: Number(b.cod_amount) || 0, external_ref: b.external_ref || null,
    delivery_otp: rnd(4), eta: 'ডেলিভারি ম্যানের অপেক্ষায়',
  };
  let p, error;
  for (let i = 0; i < 3 && !p; i++) {
    ({ data: p, error } = await db.from('parcels').insert({ ...row, tracking_id: 'BD' + rnd(6) }).select('id, tracking_id, status, delivery_otp').single());
  }
  if (!p) return NextResponse.json({ error: error?.message || 'failed' }, { status: 500 });

  await db.from('parcel_events').insert({ parcel_id: p.id, status: 0 });
  await notifyRiders({ title: 'নতুন ডেলিভারি অর্ডার', body: `${row.item} · ${row.pickup_address} → ${row.address}`, tracking_id: p.tracking_id });

  const { id: _i, ...out } = p;
  return NextResponse.json(out, { status: 201 });
}
