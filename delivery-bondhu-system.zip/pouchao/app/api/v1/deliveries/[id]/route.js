import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { shopFrom } from '@/lib/auth';
import { normalizeId } from '@/lib/steps';

// GET /api/v1/deliveries/BD123456  → current status (shop can poll)
export async function GET(req, { params }) {
  const shop = await shopFrom(req);
  if (!shop) return NextResponse.json({ error: 'invalid api key' }, { status: 401 });
  const { data } = await db.from('parcels').select('tracking_id, status, external_ref, rider:riders(name, phone)').eq('shop_id', shop.id).eq('tracking_id', normalizeId(params.id)).maybeSingle();
  return data ? NextResponse.json(data) : NextResponse.json({ error: 'not found' }, { status: 404 });
}
