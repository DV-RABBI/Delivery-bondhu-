import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { riderFrom } from '@/lib/auth';

// POST { online: boolean, subscription?: PushSubscriptionJSON }
export async function POST(req) {
  const rider = await riderFrom(req);
  if (!rider) return NextResponse.json({ error: 'লগইন করুন' }, { status: 401 });
  const { online, subscription } = await req.json();
  await db.from('riders').update({ online: !!online }).eq('id', rider.id);
  if (online && subscription?.endpoint) {
    await db.from('push_subs').upsert({ rider_id: rider.id, endpoint: subscription.endpoint, sub: subscription }, { onConflict: 'endpoint' });
  }
  return NextResponse.json({ ok: true });
}
