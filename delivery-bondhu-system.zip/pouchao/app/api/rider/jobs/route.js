import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { riderFrom } from '@/lib/auth';

const F = 'tracking_id, item, pickup_address, address, customer_name, customer_phone, cod_amount, status';

export async function GET(req) {
  const rider = await riderFrom(req);
  if (!rider) return NextResponse.json({ error: 'লগইন করুন' }, { status: 401 });
  const [a, m] = await Promise.all([
    db.from('parcels').select(F).eq('status', 0).is('rider_id', null).order('created_at', { ascending: false }).limit(20),
    db.from('parcels').select(F).eq('rider_id', rider.id).lt('status', 4).order('created_at'),
  ]);
  return NextResponse.json({ rider, available: a.data || [], mine: m.data || [] });
}
