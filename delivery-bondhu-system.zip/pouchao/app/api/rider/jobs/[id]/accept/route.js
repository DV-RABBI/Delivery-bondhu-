import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { riderFrom } from '@/lib/auth';
import { normalizeId } from '@/lib/steps';

export async function POST(req, { params }) {
  const rider = await riderFrom(req);
  if (!rider) return NextResponse.json({ error: 'লগইন করুন' }, { status: 401 });
  const { data: ok } = await db.rpc('accept_parcel', { p_tracking: normalizeId(params.id), p_rider: rider.id });
  return ok ? NextResponse.json({ ok: true }) : NextResponse.json({ error: 'অন্য কেউ অর্ডারটি নিয়ে নিয়েছে' }, { status: 409 });
}
