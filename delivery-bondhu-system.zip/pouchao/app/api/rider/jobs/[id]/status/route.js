import { NextResponse } from 'next/server';
import { db } from '@/lib/supabase';
import { riderFrom } from '@/lib/auth';
import { normalizeId } from '@/lib/steps';

// POST { status: 2|3|4, otp? }  — only forward, one step at a time
export async function POST(req, { params }) {
  const rider = await riderFrom(req);
  if (!rider) return NextResponse.json({ error: 'লগইন করুন' }, { status: 401 });
  const { status, otp } = await req.json();

  const { data: p } = await db.from('parcels').select('id, status, rider_id, delivery_otp').eq('tracking_id', normalizeId(params.id)).maybeSingle();
  if (!p || p.rider_id !== rider.id) return NextResponse.json({ error: 'পাওয়া যায়নি' }, { status: 404 });
  if (status !== p.status + 1 || status > 4) return NextResponse.json({ error: 'ধাপ ঠিক নয়' }, { status: 400 });
  if (status === 4 && String(otp) !== p.delivery_otp) return NextResponse.json({ error: 'OTP ভুল' }, { status: 400 });

  await db.from('parcels').update({ status, progress: status === 3 ? 10 : status === 4 ? 100 : 0 }).eq('id', p.id).eq('status', p.status);
  await db.from('parcel_events').insert({ parcel_id: p.id, status });
  return NextResponse.json({ ok: true });
}
